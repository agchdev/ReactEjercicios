import React from 'react'

const Contacto = () => {
  return (
    <div>Contacto</div>
  )
}

export default Contacto